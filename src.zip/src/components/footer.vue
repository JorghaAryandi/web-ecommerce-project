<template>
    <footer class="py-3 bg-dark mt-5 fixed-bottom">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; E-Commerce 2024</p>
      </div>
    </footer>
  </template>
  