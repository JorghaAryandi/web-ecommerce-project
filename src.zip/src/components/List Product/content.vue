<template>
  <section>
    <Filter />
  </section>

  <CardProduct />
</template>

<script setup lang="ts">
import Filter from "@/components/List Product/filter.vue";
import CardProduct from "@/components/List Product/cardProduct.vue";
</script>
