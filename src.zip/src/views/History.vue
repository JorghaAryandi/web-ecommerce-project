<template>
    <fancybutton>
        <History />
    </fancybutton>
</template>

<script setup lang="ts">
import fancybutton from '@/components/fancybutton.vue';
import History from '@/components/History/content.vue';

</script>