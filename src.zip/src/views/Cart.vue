<template>
    <fancybutton>
    <Content />
    </fancybutton>
    
</template>

<script setup lang="ts">
import Content from '../components/Cart/content.vue';
import fancybutton from '@/components/fancybutton.vue'; 
</script>
