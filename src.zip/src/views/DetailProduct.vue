<template>
  <Navbar />
  <Content />
  <Footer />
</template>

<script setup lang="ts">
import Navbar from "../components/navbar.vue";
import Content from "../components/Detail Product/detailProduct.vue";
import Footer from "../components/footer.vue";
</script>
