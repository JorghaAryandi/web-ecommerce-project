<template>
  <Navbar />
  <Header />
  <Content />
  <Footer />
</template>

<script setup lang="ts">
import Navbar from "../components/navbar.vue";
import Header from "../components/header.vue";
import Content from "../components/List Product/content.vue";
import Footer from "../components/footer.vue";
</script>
