<template>
    <fancybutton>
        <Profile />
    </fancybutton>
</template>

<script setup lang="ts">
import fancybutton from '@/components/fancybutton.vue';
import Profile from '@/components/Profile/content.vue';

</script>